﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PNotebook01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            String[,] Modelos = new String[3, 3];
            Double[] Media = new Double[3];
            string auxiliar = "";
            Double aux;

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite o valor do Notebook {i + 1} na loja {j + 1}");
                    if (auxiliar.Replace(" ", "").Length == 0 || !Double.TryParse(auxiliar, out aux))
                    {
                        MessageBox.Show("Valor inválido!");
                        j--;
                    }
                    else
                    {
                        Modelos[i, j] = auxiliar;
                    }
                }
            }

            for (int i = 0; i < 3; i++)
            {
                Media[i] = 0;
            }

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++) { 
                    Media[i] = (Media [i] + Convert.ToDouble(Modelos[i,j]));
                }
            }

            for (int i = 0; i < 3; i++)
            {
                lstbxProdutos.Items.Add($"Notebook: {i + 1} Loja 1: {Modelos[i, 0]} | Loja 2: {Modelos[i, 1]} | Loja 3: {Modelos[i, 2]} | Média: {(Media[i] / 3).ToString("C2")}");
            }
            lstbxProdutos.Items.Add($"-------------------------------------------------------");
            Double MediaTotal = 0;
            MediaTotal = (Media[0] + Media[1] + Media[2]) / 3;
            lstbxProdutos.Items.Add($"Media Geral Computadores: {(MediaTotal/3).ToString("C2")}");

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxProdutos.ClearSelected();
        }
    }
}
