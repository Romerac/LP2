﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            String[] Nomes = new string[10];
            int[] Tamanho = new int[10];
            string auxiliar = "";

            for (int i = 0; i < Nomes.Length; i++)
            {
                auxiliar = Interaction.InputBox(Nomes[i]);
                if(auxiliar.Replace(" ","").Length==0)
                {
                    MessageBox.Show("Valor inválido!");
                    i--;
                }
                else
                {
                    Nomes[i] = auxiliar;
                    Tamanho[i] = auxiliar.Replace(" ", "").Length;
                }
            }
            for(int i = 0;i < Tamanho.Length; i++)
            {
                lstbxNomes.Items.Add($"O nome : {Nomes[i]} tem {Tamanho[i]} characteres.");
            }
        }
    }
}
