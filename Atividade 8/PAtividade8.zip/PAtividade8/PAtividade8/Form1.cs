﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";

            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox("Digite o número", "Entrada de dados");

                if(auxiliar == "")
                {
                    break;
                }

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número Inválido");
                    i--;
                }
                
            }
            //primeira forma
            Array.Reverse(vetor);
            auxiliar = "";
            foreach (int x in vetor)
            {
                auxiliar += x + "\n";
            }
            /*segunda forma
             auxiliar = "";
            auxiliar = string.Join("\n", vetor);                
             */
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            Double[,] notas = new Double[20,3];
            string auxiliar = "";
            Double media = 0;
            string saida = "";

            for (int i = 0; i < 20; i++) { 
                media = 0;
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a {j + 1}ª nota do aluno {i + 1}: ", "Entrada de dados");
                    if (!Double.TryParse(auxiliar, out notas[i, j]) || notas[i, j] < 0 || notas[i, j] > 10)
                    {
                        MessageBox.Show("Nota inválida");
                        j--;
                    }
                    else
                    {
                        media += notas[i, j];
                    }
                } media = media / 3;
                //media /= 3;
                  saida += $"Aluno: {i+1} | Média: {media.ToString("N2")} \n";
            }
            MessageBox.Show(saida);
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            //classe         objeto
            frmExercicio4 objExercicio4 = new frmExercicio4();
            objExercicio4.Show();
        }
    }
}
