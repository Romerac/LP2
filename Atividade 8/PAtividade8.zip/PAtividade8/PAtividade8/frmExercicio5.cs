﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade8
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            String[,] Exercicios = new String[5, 10];
            char[] Respostas = new char[5];
            Respostas = new char[] { 'A', 'B', 'A', 'B', 'C', 'D', 'C', 'D', 'E', 'E' };

            string auxiliar = "";

            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a resposta do aluno {i + 1} para a questão {j + 1}:");
                    if (auxiliar.Replace(" ", "").Length == 0 || !"ABCDE".Contains(auxiliar.ToUpper()))
                    {
                        MessageBox.Show("Valor inválido!");
                        j--;
                    }
                    else
                    {
                        Exercicios[i, j] = auxiliar.ToUpper();
                    }
                }
            }

            bool[,] RespostasCorretas = new bool[5, 10];

            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    if (Exercicios[i, j].ToUpper() == Respostas[j].ToString())
                    {
                        RespostasCorretas[i, j] = true;
                        lstbxCorrecao.Items.Add($"O aluno: {i + 1} acertou a questão {j + 1}: Era: " + Respostas[j] + " | Escolheu: " + Exercicios[i, j]);

                    }
                    else
                    {
                        RespostasCorretas[i, j] = false;
                        lstbxCorrecao.Items.Add($"O aluno: {i + 1}   errou   a questão {j + 1}: Era: " + Respostas[j] + " | Escolheu: " + Exercicios[i, j]);
                    }
                }
            }
        }
    }
}
