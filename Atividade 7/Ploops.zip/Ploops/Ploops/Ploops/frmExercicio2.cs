﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Ploops
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnCalcula_Click(object sender, EventArgs e)
        {
            Double valorN = 0, valorFinal = 0;
            if (Double.TryParse(txtNumeroN.Text, out valorN))
            {
                if (valorN > 0)
                {
                    for (int i=1; i <= valorN; i++)
                    {
                        valorFinal = valorFinal + (1.0 / i);
                    }
                    MessageBox.Show("O cálculo retornou que o valor de H é igual à: "+ valorFinal.ToString("F4"));
                }
                else if (valorN <= 0)
                {
                    MessageBoxIcon icon = MessageBoxIcon.Warning;
                    MessageBox.Show("NUMERO INVÁLIDO: Digite um número inteiro positivo, por favor.");
                }
            }
        }
    }   
}
