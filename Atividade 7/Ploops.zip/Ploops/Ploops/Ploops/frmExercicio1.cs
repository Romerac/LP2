﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class frmExercicio1 : Form
    {
        
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnEspaçoBranco_Click(object sender, EventArgs e)
        {
            int contador = 0;
            foreach (char c in rchtxtFrasona.Text)
            {
                if (char.IsWhiteSpace(c))
                {
                    contador++;
                }
            }
            MessageBox.Show("Quantidade de espaços em branco no texto: " + contador);
        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            int i = 0;
            int contador = 0;
            while (i < rchtxtFrasona.Text.Length)
            {
                if (rchtxtFrasona.Text[i] == 'R' || rchtxtFrasona.Text[i] == 'r')
                {
                    contador++;
                }
                i++;
            }
            MessageBox.Show("Quantidade de letras R no texto: " + contador);
        }

        private void btnRepeteLetra_Click(object sender, EventArgs e)
        {
            int contador = 0;
            for (int i = 0; i < (rchtxtFrasona.Text.Length - 1); i++){
                if (rchtxtFrasona.Text[i] == ' ')
                {
                    i++;
                }
                else if (rchtxtFrasona.Text[i + 1] == rchtxtFrasona.Text[i])
                {
                    contador++;
                }
            }
            MessageBox.Show("Quantidade de letras repetidas no texto: " + contador);
        }
    }
}
