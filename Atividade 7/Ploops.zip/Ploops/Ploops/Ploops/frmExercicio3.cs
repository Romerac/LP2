﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnVerificarPali_Click(object sender, EventArgs e)
        {   
            String Texto = txtTexto.Text.ToLower();

            foreach (char c in Texto)
            {
                if (!char.IsLetterOrDigit(c))
                {
                    Texto = Texto.Replace(c.ToString(), "");                          // Remove espaços em branco
                }
            }


            String TextoInvertido = new string(Texto.Reverse().ToArray());            // Inverte a string


            // COMO REMOVER ACENTOS ??? Perguntar pra prof.


            // Verifica se o texto original é igual ao texto invertido
            if (Texto == TextoInvertido)
            {
                MessageBox.Show("A palavra ou frase digitada é um palíndromo.");
            }
            else if (Texto != TextoInvertido)
            {
                MessageBox.Show("A palavra ou frase digitada não é um palíndromo.");
            }
        }
    }
}
