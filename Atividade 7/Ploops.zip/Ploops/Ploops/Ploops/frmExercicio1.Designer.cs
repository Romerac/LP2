﻿namespace Ploops
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrasona = new System.Windows.Forms.RichTextBox();
            this.btnEspaçoBranco = new System.Windows.Forms.Button();
            this.btnLetraR = new System.Windows.Forms.Button();
            this.btnRepeteLetra = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrasona
            // 
            this.rchtxtFrasona.Location = new System.Drawing.Point(13, 13);
            this.rchtxtFrasona.MaxLength = 100;
            this.rchtxtFrasona.Name = "rchtxtFrasona";
            this.rchtxtFrasona.Size = new System.Drawing.Size(775, 247);
            this.rchtxtFrasona.TabIndex = 0;
            this.rchtxtFrasona.Text = "";
            // 
            // btnEspaçoBranco
            // 
            this.btnEspaçoBranco.Location = new System.Drawing.Point(13, 317);
            this.btnEspaçoBranco.Name = "btnEspaçoBranco";
            this.btnEspaçoBranco.Size = new System.Drawing.Size(172, 80);
            this.btnEspaçoBranco.TabIndex = 1;
            this.btnEspaçoBranco.Text = "Número de espaços em branco existentes no texto :";
            this.btnEspaçoBranco.UseVisualStyleBackColor = true;
            this.btnEspaçoBranco.Click += new System.EventHandler(this.btnEspaçoBranco_Click);
            // 
            // btnLetraR
            // 
            this.btnLetraR.Location = new System.Drawing.Point(316, 317);
            this.btnLetraR.Name = "btnLetraR";
            this.btnLetraR.Size = new System.Drawing.Size(172, 80);
            this.btnLetraR.TabIndex = 2;
            this.btnLetraR.Text = "Número de vezes que a letra \"R\" é encontrada no texto :";
            this.btnLetraR.UseVisualStyleBackColor = true;
            this.btnLetraR.Click += new System.EventHandler(this.btnLetraR_Click);
            // 
            // btnRepeteLetra
            // 
            this.btnRepeteLetra.Location = new System.Drawing.Point(616, 317);
            this.btnRepeteLetra.Name = "btnRepeteLetra";
            this.btnRepeteLetra.Size = new System.Drawing.Size(172, 80);
            this.btnRepeteLetra.TabIndex = 3;
            this.btnRepeteLetra.Text = "Número de vezes que ocorre um mesmo par de letras na frase :";
            this.btnRepeteLetra.UseVisualStyleBackColor = true;
            this.btnRepeteLetra.Click += new System.EventHandler(this.btnRepeteLetra_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnRepeteLetra);
            this.Controls.Add(this.btnLetraR);
            this.Controls.Add(this.btnEspaçoBranco);
            this.Controls.Add(this.rchtxtFrasona);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrasona;
        private System.Windows.Forms.Button btnEspaçoBranco;
        private System.Windows.Forms.Button btnLetraR;
        private System.Windows.Forms.Button btnRepeteLetra;
    }
}