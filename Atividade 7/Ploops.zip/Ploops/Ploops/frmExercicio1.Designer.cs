﻿namespace Ploops
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrasona = new System.Windows.Forms.RichTextBox();
            this.btnEspaçoBranco = new System.Windows.Forms.Button();
            this.btnLetraR = new System.Windows.Forms.Button();
            this.btnRepeteLetra = new System.Windows.Forms.Button();
            this.lblDigiteTexto = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // rchtxtFrasona
            // 
            this.rchtxtFrasona.BackColor = System.Drawing.Color.Bisque;
            this.rchtxtFrasona.Location = new System.Drawing.Point(9, 65);
            this.rchtxtFrasona.Margin = new System.Windows.Forms.Padding(2);
            this.rchtxtFrasona.MaxLength = 100;
            this.rchtxtFrasona.Name = "rchtxtFrasona";
            this.rchtxtFrasona.Size = new System.Drawing.Size(1011, 335);
            this.rchtxtFrasona.TabIndex = 0;
            this.rchtxtFrasona.Text = "";
            // 
            // btnEspaçoBranco
            // 
            this.btnEspaçoBranco.BackColor = System.Drawing.Color.LightSalmon;
            this.btnEspaçoBranco.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEspaçoBranco.Location = new System.Drawing.Point(9, 447);
            this.btnEspaçoBranco.Margin = new System.Windows.Forms.Padding(2);
            this.btnEspaçoBranco.Name = "btnEspaçoBranco";
            this.btnEspaçoBranco.Size = new System.Drawing.Size(214, 123);
            this.btnEspaçoBranco.TabIndex = 1;
            this.btnEspaçoBranco.Text = "Número de espaços em branco existentes no texto :";
            this.btnEspaçoBranco.UseVisualStyleBackColor = false;
            this.btnEspaçoBranco.Click += new System.EventHandler(this.btnEspaçoBranco_Click);
            // 
            // btnLetraR
            // 
            this.btnLetraR.BackColor = System.Drawing.Color.YellowGreen;
            this.btnLetraR.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetraR.Location = new System.Drawing.Point(407, 447);
            this.btnLetraR.Margin = new System.Windows.Forms.Padding(2);
            this.btnLetraR.Name = "btnLetraR";
            this.btnLetraR.Size = new System.Drawing.Size(214, 123);
            this.btnLetraR.TabIndex = 2;
            this.btnLetraR.Text = "Número de vezes que a letra \"R\" é encontrada no texto :";
            this.btnLetraR.UseVisualStyleBackColor = false;
            this.btnLetraR.Click += new System.EventHandler(this.btnLetraR_Click);
            // 
            // btnRepeteLetra
            // 
            this.btnRepeteLetra.BackColor = System.Drawing.Color.PowderBlue;
            this.btnRepeteLetra.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRepeteLetra.Location = new System.Drawing.Point(806, 447);
            this.btnRepeteLetra.Margin = new System.Windows.Forms.Padding(2);
            this.btnRepeteLetra.Name = "btnRepeteLetra";
            this.btnRepeteLetra.Size = new System.Drawing.Size(214, 123);
            this.btnRepeteLetra.TabIndex = 3;
            this.btnRepeteLetra.Text = "Número de vezes que ocorre um mesmo par de letras na frase :";
            this.btnRepeteLetra.UseVisualStyleBackColor = false;
            this.btnRepeteLetra.Click += new System.EventHandler(this.btnRepeteLetra_Click);
            // 
            // lblDigiteTexto
            // 
            this.lblDigiteTexto.AutoSize = true;
            this.lblDigiteTexto.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDigiteTexto.ForeColor = System.Drawing.SystemColors.Control;
            this.lblDigiteTexto.Location = new System.Drawing.Point(330, 9);
            this.lblDigiteTexto.Name = "lblDigiteTexto";
            this.lblDigiteTexto.Size = new System.Drawing.Size(377, 36);
            this.lblDigiteTexto.TabIndex = 4;
            this.lblDigiteTexto.Text = "Digite um texto qualquer :";
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1031, 593);
            this.Controls.Add(this.lblDigiteTexto);
            this.Controls.Add(this.btnRepeteLetra);
            this.Controls.Add(this.btnLetraR);
            this.Controls.Add(this.btnEspaçoBranco);
            this.Controls.Add(this.rchtxtFrasona);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrasona;
        private System.Windows.Forms.Button btnEspaçoBranco;
        private System.Windows.Forms.Button btnLetraR;
        private System.Windows.Forms.Button btnRepeteLetra;
        private System.Windows.Forms.Label lblDigiteTexto;
    }
}