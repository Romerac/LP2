﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class frmExercicio4 : Form
    {
        Double salario, gratificacao, producao;
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnSalarioBruto_Click(object sender, EventArgs e)
        {
            //Calculo porcentagens
            /*
                A=salário de acordo com o cargo (plano de carreira)
                B=Produção >=100 -> se sim B=1 caso contrário B=0
                C=Produção >=120 -> se sim C=1 caso contrário C=0
                D=Produção >=150 -> se sim D=1 caso contrário D=0
            */
            byte B, C, D;
            B = 0; C = 0; D = 0; // Inicializa as variáveis B, C e D com zero   
            
            if (producao < 100)
            {
                B = 0;
                C = 0;
                D = 0;
            }if (producao >= 100 && producao < 120)
            {
                B = 1;
                C = 0;
                D = 0;
            }
            if (producao >= 120 && producao < 150)
            {
                B = 1;
                C = 1;
                D = 0;
            }
            else if (producao >= 150)
            {
                B = 1;
                C = 1;
                D = 1;
            }

            /*Calculo do salario
            A forma de cálculo do salário bruto dos funcionários de uma empresa é a seguinte:
            salário bruto = A + Ax(0, 05xB + 0, 1xC + 0, 1xD) + Total de gratificações.
            */
            Double salarioBruto;
            
            salarioBruto = salario + salario * (0.05 * Convert.ToDouble(B) + 0.1 * Convert.ToDouble(C) + 0.1 * Convert.ToDouble(D)) + gratificacao;

            //Restrição: O maior Salário Bruto a ser pago é 7.000,00.
            //Valor acima de 7.000,00 só poderá ser pago a funcionários com Produção>=150 e que tenham gratificação.
            if (salarioBruto > 7000)
            {
                if (producao < 150 || gratificacao <= 0)
                {
                    salarioBruto = 7000;
                }
            }

            mskdSalarioBruto.Text = salarioBruto.ToString();
        }

        

        private void txtNome_Validated(object sender, EventArgs e)
        {
            //Verifica se os campos TEXTO são válidos

            String Nome = txtNome.Text;

            if (!Nome.All(char.IsLetter))
            {
                MessageBox.Show("Dado inválido! Digite um nome válido");
                txtNome.Focus();
            }
            else if (Nome == "")
            {
                MessageBox.Show("Dado inválido! Digite um nome válido");
                txtNome.Focus();
            }
        }

            //Verifica se os campos são válidos

        private void txtProducao_Validated(object sender, EventArgs e)
        {

            if (!Double.TryParse(txtProducao.Text, out producao))
            {
                MessageBox.Show("Dado inválido! Digite um valor de produção válido");
                txtProducao.Focus();
            }else if (producao < 0)
            {
                MessageBox.Show("Dado inválido! Digite um valor de produção válido");
                txtProducao.Focus();
            }
        }

        private void mskdSalario_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskdSalario.Text, out salario))
            {
                MessageBox.Show("Dado inválido! Digite um valor de salário válido");
                mskdSalario.Focus();
            }
            else if (salario < 0)
            {
                MessageBox.Show("Dado inválido! Digite um valor de produção válido");
                mskdSalario.Focus();
            }
        }
        private void mskdGratificacao_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskdGratificacao.Text, out gratificacao))
            {
                MessageBox.Show("Dado inválido! Digite um valor de gratificação válido");
                mskdGratificacao.Focus();
            }
            if (gratificacao < 0)
            {
                MessageBox.Show("Dado inválido! Digite um valor de produção válido");
                mskdGratificacao.Focus();
            }
        }
    }
}
