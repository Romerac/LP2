﻿namespace Ploops
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtProducao = new System.Windows.Forms.TextBox();
            this.btnSalarioBruto = new System.Windows.Forms.Button();
            this.mskdSalario = new System.Windows.Forms.MaskedTextBox();
            this.mskdGratificacao = new System.Windows.Forms.MaskedTextBox();
            this.mskdSalarioBruto = new System.Windows.Forms.MaskedTextBox();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.lblProducao = new System.Windows.Forms.Label();
            this.lblSalario = new System.Windows.Forms.Label();
            this.lblGratificacao = new System.Windows.Forms.Label();
            this.lblSalarioBruto = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.ForeColor = System.Drawing.Color.Snow;
            this.lblNome.Location = new System.Drawing.Point(59, 32);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(58, 19);
            this.lblNome.TabIndex = 90;
            this.lblNome.Text = "Nome: ";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(176, 31);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(254, 20);
            this.txtNome.TabIndex = 1;
            this.txtNome.Validated += new System.EventHandler(this.txtNome_Validated);
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(176, 62);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(100, 20);
            this.txtMatricula.TabIndex = 2;
            // 
            // txtProducao
            // 
            this.txtProducao.Location = new System.Drawing.Point(176, 92);
            this.txtProducao.Name = "txtProducao";
            this.txtProducao.Size = new System.Drawing.Size(100, 20);
            this.txtProducao.TabIndex = 3;
            this.txtProducao.Validated += new System.EventHandler(this.txtProducao_Validated);
            // 
            // btnSalarioBruto
            // 
            this.btnSalarioBruto.BackColor = System.Drawing.Color.Wheat;
            this.btnSalarioBruto.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalarioBruto.Location = new System.Drawing.Point(451, 32);
            this.btnSalarioBruto.Name = "btnSalarioBruto";
            this.btnSalarioBruto.Size = new System.Drawing.Size(207, 139);
            this.btnSalarioBruto.TabIndex = 7;
            this.btnSalarioBruto.Text = "calcular salário bruto";
            this.btnSalarioBruto.UseVisualStyleBackColor = false;
            this.btnSalarioBruto.Click += new System.EventHandler(this.btnSalarioBruto_Click);
            // 
            // mskdSalario
            // 
            this.mskdSalario.Location = new System.Drawing.Point(176, 121);
            this.mskdSalario.Name = "mskdSalario";
            this.mskdSalario.Size = new System.Drawing.Size(100, 20);
            this.mskdSalario.TabIndex = 4;
            this.mskdSalario.Validated += new System.EventHandler(this.mskdSalario_Validated);
            // 
            // mskdGratificacao
            // 
            this.mskdGratificacao.Location = new System.Drawing.Point(176, 151);
            this.mskdGratificacao.Name = "mskdGratificacao";
            this.mskdGratificacao.Size = new System.Drawing.Size(100, 20);
            this.mskdGratificacao.TabIndex = 5;
            this.mskdGratificacao.Validated += new System.EventHandler(this.mskdGratificacao_Validated);
            // 
            // mskdSalarioBruto
            // 
            this.mskdSalarioBruto.Location = new System.Drawing.Point(176, 223);
            this.mskdSalarioBruto.Name = "mskdSalarioBruto";
            this.mskdSalarioBruto.Size = new System.Drawing.Size(100, 20);
            this.mskdSalarioBruto.TabIndex = 6;
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMatricula.ForeColor = System.Drawing.Color.Snow;
            this.lblMatricula.Location = new System.Drawing.Point(59, 63);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(88, 19);
            this.lblMatricula.TabIndex = 91;
            this.lblMatricula.Text = "Matrícula : ";
            // 
            // lblProducao
            // 
            this.lblProducao.AutoSize = true;
            this.lblProducao.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProducao.ForeColor = System.Drawing.Color.Snow;
            this.lblProducao.Location = new System.Drawing.Point(59, 93);
            this.lblProducao.Name = "lblProducao";
            this.lblProducao.Size = new System.Drawing.Size(84, 19);
            this.lblProducao.TabIndex = 92;
            this.lblProducao.Text = "Produção : ";
            // 
            // lblSalario
            // 
            this.lblSalario.AutoSize = true;
            this.lblSalario.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalario.ForeColor = System.Drawing.Color.Snow;
            this.lblSalario.Location = new System.Drawing.Point(59, 122);
            this.lblSalario.Name = "lblSalario";
            this.lblSalario.Size = new System.Drawing.Size(69, 19);
            this.lblSalario.TabIndex = 93;
            this.lblSalario.Text = "Salário : ";
            // 
            // lblGratificacao
            // 
            this.lblGratificacao.AutoSize = true;
            this.lblGratificacao.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGratificacao.ForeColor = System.Drawing.Color.Snow;
            this.lblGratificacao.Location = new System.Drawing.Point(59, 152);
            this.lblGratificacao.Name = "lblGratificacao";
            this.lblGratificacao.Size = new System.Drawing.Size(104, 19);
            this.lblGratificacao.TabIndex = 94;
            this.lblGratificacao.Text = "Gratificação : ";
            // 
            // lblSalarioBruto
            // 
            this.lblSalarioBruto.AutoSize = true;
            this.lblSalarioBruto.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalarioBruto.ForeColor = System.Drawing.Color.Snow;
            this.lblSalarioBruto.Location = new System.Drawing.Point(59, 223);
            this.lblSalarioBruto.Name = "lblSalarioBruto";
            this.lblSalarioBruto.Size = new System.Drawing.Size(111, 19);
            this.lblSalarioBruto.TabIndex = 95;
            this.lblSalarioBruto.Text = "Salário Bruto : ";
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaGreen;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblSalarioBruto);
            this.Controls.Add(this.lblGratificacao);
            this.Controls.Add(this.lblSalario);
            this.Controls.Add(this.lblProducao);
            this.Controls.Add(this.lblMatricula);
            this.Controls.Add(this.mskdSalarioBruto);
            this.Controls.Add(this.mskdGratificacao);
            this.Controls.Add(this.mskdSalario);
            this.Controls.Add(this.btnSalarioBruto);
            this.Controls.Add(this.txtProducao);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblNome);
            this.MaximizeBox = false;
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtProducao;
        private System.Windows.Forms.Button btnSalarioBruto;
        private System.Windows.Forms.MaskedTextBox mskdSalario;
        private System.Windows.Forms.MaskedTextBox mskdGratificacao;
        private System.Windows.Forms.MaskedTextBox mskdSalarioBruto;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.Label lblProducao;
        private System.Windows.Forms.Label lblSalario;
        private System.Windows.Forms.Label lblGratificacao;
        private System.Windows.Forms.Label lblSalarioBruto;
    }
}