﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        Double number1, number2, calculation=0;
        public Form1()
        {
            InitializeComponent();
        }
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtNumber1.Clear();
            txtNumber2.Clear();
            txtResult.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void btnMinus_Click(object sender, EventArgs e)
        {
            calculation = (number1 - number2);
            txtResult.Text = calculation.ToString();
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            calculation = number1 * number2;
            txtResult.Text = calculation.ToString();
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            if (number2 == 0)
            {
                MessageBox.Show("Não é possível dividir por zero!");
                txtNumber2.Focus();
            }
            else
            {
                calculation = number1 / number2;
                txtResult.Text = calculation.ToString();
            }
        }
            
        private void txtNumber2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumber2.Text, out number2))
            {
                MessageBox.Show("Número 2 é inválido!");
                txtNumber1.Focus();
            }
        }

        private void txtNumber1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumber1.Text, out number1))
            {
                MessageBox.Show("Número 1 é inválido!");
                txtNumber1.Focus();
            }
        }

        private void btnPlus_Click(object sender, EventArgs e)
        {
            calculation = (number1 + number2);
            txtResult.Text=calculation.ToString();
        }
    }
}
