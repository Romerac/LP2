﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class frmExercicio5 : Form
    {
        int num1, num2;
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNum1.Text, out int num1) || !int.TryParse(txtNum2.Text, out int num2) || num2 <= num1)
            {
                MessageBox.Show("Números inválidos");
                txtNum1.Clear();
                txtNum2.Clear();
                txtNum1.Focus();
                return;
            }
            else 
            { 
                Random objR = new Random();
                int aleatorio = objR.Next(num1, num2);
                MessageBox.Show(aleatorio.ToString());
                //ou
                //mbox  .Show("Número aleatório: " + aleatório);
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
        }
    }
}
