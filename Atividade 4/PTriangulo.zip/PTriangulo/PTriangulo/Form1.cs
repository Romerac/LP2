﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        Double ladoA;
        Double ladoB;
        Double ladoC;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecuta_Click(object sender, EventArgs e)
        {
            btnTestarTriangulo.PerformClick();

            if (ladoA == ladoB && ladoB == ladoC && ladoA != 0 && ladoB != 0 && ladoC != 0)
            {
                MessageBox.Show("O triângulo informado é um Triângulo Equilátero.");
            }
            else if (ladoA == ladoB || ladoB == ladoC || ladoC == ladoA && ladoA != 0 && ladoB != 0 && ladoC != 0)
            {
                MessageBox.Show("O triângulo informado é um Triângulo Isósceles.");
            }
            else if (ladoA != ladoB || ladoB != ladoC || ladoC != ladoA && ladoA != 0 && ladoB != 0 && ladoC != 0)
            {
                MessageBox.Show("O triângulo informado é um Triângulo Escaleno.");
            }
            
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }
        
        /*private bool ValidarEntradas()
        {
            if (!Double.TryParse(txtLadoA.Text, out ladoA) ||
                !Double.TryParse(txtLadoB.Text, out ladoB) ||
                !Double.TryParse(txtLadoC.Text, out ladoC))
            {
                MessageBox.Show("Algum dos dados inseridos é inválido!");
                return false;
            }
            return true;
        }*/

        private void btnTestarTriangulo_Click(object sender, EventArgs e)
        {
            if (Math.Abs(ladoB-ladoC) < ladoA && ladoA  < ladoB + ladoC)
            {
                MessageBox.Show("É triângulo!");
            }
            else if (Math.Abs(ladoA - ladoC) < ladoB && ladoB < ladoA + ladoC)
            {
                MessageBox.Show("É triângulo!");
            }
            else if (Math.Abs(ladoA - ladoB) < ladoC && ladoC < ladoA + ladoB)
            {
                MessageBox.Show("É triângulo!");
            }
            else
            {
                MessageBox.Show("Não é triângulo!");
                txtLadoA.Clear();
                txtLadoB.Clear();
                txtLadoC.Clear();
                txtLadoA.Focus();
            }
        }

        private void txtLadoA_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(txtLadoA.Text, out ladoA))
            {
                MessageBox.Show("Algum dos dados inseridos é invalido!");
                txtLadoA.Clear();
                txtLadoA.Focus();
            }
        }

        private void txtLadoB_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(txtLadoB.Text, out ladoB))
            {
                MessageBox.Show("Algum dos dados inseridos é invalido!");
                txtLadoB.Focus();
                txtLadoB.Clear();
            }
        }

        private void txtLadoC_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(txtLadoC.Text, out ladoC))
            {
                MessageBox.Show("Algum dos dados inseridos é invalido!");
                txtLadoC.Focus();
                txtLadoC.Clear();
            }
        }
    }
}
