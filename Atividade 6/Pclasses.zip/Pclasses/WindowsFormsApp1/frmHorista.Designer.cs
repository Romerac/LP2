﻿namespace WindowsFormsApp1
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInstanciar = new System.Windows.Forms.Button();
            this.txtHora = new System.Windows.Forms.TextBox();
            this.txtSalario = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.lblDataEntradaEmpresa = new System.Windows.Forms.Label();
            this.lblSalarioHora = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.lblHora = new System.Windows.Forms.Label();
            this.txtData = new System.Windows.Forms.TextBox();
            this.txtFalta = new System.Windows.Forms.TextBox();
            this.lblFalta = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnInstanciar
            // 
            this.btnInstanciar.Location = new System.Drawing.Point(464, 348);
            this.btnInstanciar.Name = "btnInstanciar";
            this.btnInstanciar.Size = new System.Drawing.Size(185, 77);
            this.btnInstanciar.TabIndex = 20;
            this.btnInstanciar.Text = "Instanciar Horista";
            this.btnInstanciar.UseVisualStyleBackColor = true;
            this.btnInstanciar.Click += new System.EventHandler(this.btnInstanciar_Click);
            // 
            // txtHora
            // 
            this.txtHora.Location = new System.Drawing.Point(464, 186);
            this.txtHora.Name = "txtHora";
            this.txtHora.Size = new System.Drawing.Size(185, 26);
            this.txtHora.TabIndex = 17;
            // 
            // txtSalario
            // 
            this.txtSalario.Location = new System.Drawing.Point(464, 132);
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(185, 26);
            this.txtSalario.TabIndex = 16;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(257, 85);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(392, 26);
            this.txtNome.TabIndex = 15;
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(464, 38);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(185, 26);
            this.txtMatricula.TabIndex = 14;
            // 
            // lblDataEntradaEmpresa
            // 
            this.lblDataEntradaEmpresa.AutoSize = true;
            this.lblDataEntradaEmpresa.Location = new System.Drawing.Point(151, 239);
            this.lblDataEntradaEmpresa.Name = "lblDataEntradaEmpresa";
            this.lblDataEntradaEmpresa.Size = new System.Drawing.Size(217, 20);
            this.lblDataEntradaEmpresa.TabIndex = 13;
            this.lblDataEntradaEmpresa.Text = "Data de Entrada na Empresa";
            // 
            // lblSalarioHora
            // 
            this.lblSalarioHora.AutoSize = true;
            this.lblSalarioHora.Location = new System.Drawing.Point(151, 138);
            this.lblSalarioHora.Name = "lblSalarioHora";
            this.lblSalarioHora.Size = new System.Drawing.Size(124, 20);
            this.lblSalarioHora.TabIndex = 12;
            this.lblSalarioHora.Text = "Salario por Hora";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(151, 88);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(51, 20);
            this.lblNome.TabIndex = 11;
            this.lblNome.Text = "Nome";
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Location = new System.Drawing.Point(151, 44);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(73, 20);
            this.lblMatricula.TabIndex = 10;
            this.lblMatricula.Text = "Matricula";
            // 
            // lblHora
            // 
            this.lblHora.AutoSize = true;
            this.lblHora.Location = new System.Drawing.Point(151, 192);
            this.lblHora.Name = "lblHora";
            this.lblHora.Size = new System.Drawing.Size(134, 20);
            this.lblHora.TabIndex = 20;
            this.lblHora.Text = "Número de Horas";
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(464, 233);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(185, 26);
            this.txtData.TabIndex = 18;
            // 
            // txtFalta
            // 
            this.txtFalta.Location = new System.Drawing.Point(464, 283);
            this.txtFalta.Name = "txtFalta";
            this.txtFalta.Size = new System.Drawing.Size(185, 26);
            this.txtFalta.TabIndex = 19;
            // 
            // lblFalta
            // 
            this.lblFalta.AutoSize = true;
            this.lblFalta.Location = new System.Drawing.Point(151, 289);
            this.lblFalta.Name = "lblFalta";
            this.lblFalta.Size = new System.Drawing.Size(106, 20);
            this.lblFalta.TabIndex = 23;
            this.lblFalta.Text = "Dias de faltas";
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblFalta);
            this.Controls.Add(this.txtFalta);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.lblHora);
            this.Controls.Add(this.btnInstanciar);
            this.Controls.Add(this.txtHora);
            this.Controls.Add(this.txtSalario);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.lblDataEntradaEmpresa);
            this.Controls.Add(this.lblSalarioHora);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMatricula);
            this.Name = "frmHorista";
            this.Text = "frmHorista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnInstanciar;
        private System.Windows.Forms.TextBox txtHora;
        private System.Windows.Forms.TextBox txtSalario;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.Label lblDataEntradaEmpresa;
        private System.Windows.Forms.Label lblSalarioHora;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.Label lblHora;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.TextBox txtFalta;
        private System.Windows.Forms.Label lblFalta;
    }
}